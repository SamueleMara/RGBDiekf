# RGBDiekf correspondence/debug visualization audit — 2026-10-22

## Inputs and version
- User's uploaded `reuslts(3).zip` and `reuslts(4).zip` are byte-identical, MD5 `353e6fd882b2951f245dcc0daacec19f`.
- Provided visual reference: `rigid_phase2_debug.html`, 8,238,150 bytes.
- Code checked: SamueleMara/RGBDiekf `main` commit `dd4426edcbac772b45a6f634b7c6c665b3651b8c`.
- User's Markdown Codex debug log agrees numerically with the attached audit; it is not a second independent validation.
- Numerical audit covers 328 frames x 3 cameras, 54,970,499 valid observations.

## Coverage
Original ownership: 36,535,367 covered, 18,435,132 uncovered (66.4636%).
New geometry: 45,855,798 covered, 9,114,701 uncovered (83.4189%).
New geometry + RGB: 44,810,732 covered, 10,159,767 uncovered (81.5178%).
4,850,505 prior unowned samples recover strictly from the nonexclusive ownership ablation (26.31% of old unowned).
1,179,399 geometry+appearance-unexplained raw observations still have frozen measurement owners (consistency conflicts, not eligible new seeds).
8,980,368 are unowned+unexplained under the appearance policy; not equal to distinct unseen surface points.

## Critical HTML / visualization defects

- Production `pointwise_rgbd/visualization.py::trajectory_viewer`: hard display cap `min(512,store.n0)` and max 64 appended discovery tracks; sparse display misrepresents complete coverage.
- Current audit 3D HTML `coverage_comparison.html`: 8 representative frame snapshots ONLY, 4096 SOLVED and up to 6000 per camera/view. This is an honest labeled sample but not a complete viewer for a 328-frame run.
- The audit viewer uses Plotly scatter3d and defaults to measured-surface bounding axis ranges (`scene[a].range`), which clip outlying transported tracks. 'Show all frozen estimates' makes the object tiny due to outliers.
- The 328-frame trajectory viewer uses dynamic `Plotly.react` with `aspectmode='data'`; orbit pan/zoom is not the same predictable interaction as the user's reference.
- Reference uses Three.js with persistent BufferGeometry, dark `#0e1116`, `#161b22` panel, checkbox layers, bottom timeline, consistent camera orbit, pan and wheel zoom.
- At frame 327 from actual HTML arrays, SOLVED display sample count=4096, observed-update count=1728, prediction-only count=2368.
- At frame 327, 95.1% of observed-updated sampled old points are inside measured bounds, but only 17.6% of prediction-only points are. Overall 50.3% of sampled SOLVED lie inside measured bounds.
- Frame 327 sampled prediction ranges: world X [-32.75,12.37], Y[-32.39,26.77], Z[-12.14,15.87] m. Measured region X[-1.07,-0.54],Y[0.13,0.62],Z[-0.045,0.46] m. Wide scatter is genuine saved prediction data, not purely a plotting bug.
- The rendered PNG `world_coverage.preview.png` also fits the extreme outliers, showing why the object collapses to a tiny cluster in the old preview.

## Additional scientific concern

The corrected surface matcher admits points with extremely large propagated covariance using the bound `2(P_xyz + Sigma_observed)` and compatibility tests. High uncertainty grows the compatible spatial region. One new track reportedly achieved max principal position uncertainty 0.850152m and +425,893 appearance-compatible coverage observations, but only +172 actual assimilated observations. This is not proof that 425,893 new physical geometry observations were recovered.
Report and plot coverage broken down by witness observed vs prediction-only, last real measurement age, and covariance eigenvalues. Do not silently "fix" by hiding points, inventing noise thresholds or switching the motion model without validation.

## Deliverables in this package

`RGBDiekf_reference_style_coverage_comparison.html`: a **standalone HTML** using the same dark sidebar, bottom timeline, THREE GPU-buffer point-cloud layers, orbit/pan/wheel interactions as reference. Data is sampled from the attached report and contains exactly the eight true exported timestamps (no invented intermediate frames). The file uses the same r160 CDN as the user-supplied reference; Three.js needs internet connectivity for loading.

`preview_from_actual_sample.png`: a **static Matplotlib preview**, not a verified browser screenshot. Points and counts come from frame 327 / cam_000 attached samples.

`CODEX_FIX_RGBDiekf_VISUALIZATION_REFERENCE_STYLE.md`: surgical implementation contract to port this style to the full 328-frame source dataset, remove hidden caps, and preserve both numerical and source semantics.

## Validation and limitation

The new HTML's JavaScript passed `node --check`, and its embedded dataset was parsed and spot-validated. Headless browser navigation was prevented by the container administrator's URL policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), so rendered runtime interaction has **not** been verified inside this environment. Codex must run the requested headless browser tests on its host with GPU/WebGL access before treating it as production.
