# Codex: replace RGBDiekf HTML visualization with the reference `rigid_phase2_debug.html` interaction and layout

**Source inspection:** `SamueleMara/RGBDiekf`, branch `main`, audited 22 October 2026.
**User-provided reference:** `rigid_phase2_debug.html` (visual interaction and layout ONLY).
**Reference-style working sample:** `RGBDiekf_reference_style_coverage_comparison.html` (8 true snapshot frames and real sampled XYZ from `reuslts(4).zip`).

## Critical scope

This is a **visualization and diagnostics correction**, not an estimator redesign.

Do NOT add Gaussian parameters, SE(3) states, rigid grouping, rendering-based losses, smoothing, or reoptimization.
Do NOT change the 6D IEKF, frozen trajectories, correspondence ownership, coverage metrics, point identities, or saved numerical results.
Use the appearance and interaction patterns of the provided reference without importing its Phase-2 model or its rigid-body math.

## Verified code problems to fix

1. `pointwise_rgbd/visualization.py::trajectory_viewer` currently contains:
   `ids=np.linspace(0,store.n0-1,min(512,store.n0),dtype=int)`
   which renders **at most 512 of 184,274 initially SOLVED points (0.28%)**.
2. The same function truncates discovery tracks via `if len(chosen)>64:chosen=chosen[-64:]`. This hides earlier valid discoveries without a user choice.
3. It rebuilds Plotly 3D traces using `Plotly.react` with `scene:{aspectmode:'data'}`. The scene is distorted by prediction-only tracks propagated meters or tens of meters away from the actual object.
4. `tools/audit_surface_correspondence.py::visual()` hard-caps the world HTML to 4096 SOLVED + up to 4096 explained + up to 4096 unexplained points. Its top-level comparison HTML embeds 4096 SOLVED and 6000 observed points for each of only 8 representative frames. Both are legitimate **sampling for illustration**, but they do not provide a real full-resolution temporal diagnostic and cannot support completeness claims.
5. `coverage_comparison.html` provides a choice between fixed measured-surface bounding-box axis ranges (which clip/hide many predictions) and all-prediction bounds (which shrink the actual object). At frame 327, on the embedded 4096-point sample, **2368 are prediction-only**, with only **17.6% of those inside measured-surface bounds**. Conversely, **95.1% of the 1728 directly measured-updated samples** remain inside those bounds.
6. `pointwise_rgbd/visualization.py::image_overlays` also samples old projections via `[::max(1,store.n0//1000)]`. Make this clearly user-configurable and show exact counts; distinguish actual filter input from visual decimation.

## Exact reference-style user interface

Create a reusable Three.js-style viewer matching the layout of `rigid_phase2_debug.html`:

- Very dark background `#0e1116`.
- Viewport occupies remaining full height/width; fixed right panel 370-380px with `#161b22` and `#2a313a` border.
- Small monospace typography, `#58a6ff` section headings, numerical readouts.
- Bottom frame slider and playback controls.
- Left-drag rotate, right-drag pan, wheel zoom; preserve camera attitude when advancing frames.
- Persistent GPU BufferGeometry for point layers: update positions and draw ranges per frame, **do not reallocate all 3D traces on every slider event**.
- Independent checkbox layers with stable colors.
- `Focus measured region` / `Fit all predictions` / `Reset camera`. Default object-centered ROI derived from actual measured foreground geometry. NEVER silently delete outliers: keep separate toggleable outlier layer and show its exact count.
- Exactly the same world coordinate frame and meter units for SOLVED and observed clouds.
- Camera selector and visual comparison of baseline ownership coverage, geometry-only coverage, and geometry+RGB coverage.
- Surface-explained observations, unexplained observations, frozen-assimilated-but-policy-incompatible observations must have separate layers, not be merged into one "new geometry" category.
- Show new SOLVED trajectories vs frozen old tracks with user selectable point ID and frame; distinguish **measured updates** and **prediction-only states** at every timestamp.
- Numeric per-frame fields: full point total, shown points, directly observed old points, predicted-only old points, predicted outside measured-region box, valid RGB-D observations, covered/uncovered counts by policy, owned-but-incompatible conflicts, position covariance summary and last observation age when available.
- No assumption that a prediction-only track represents physically observed surface. The labels must say "predicted".
- Optional camera frustums and axes from actual calibration if available. No fictional markers or ground-truth values.

## Full sequence and rendering budgets

The production pointwise viewer MUST expose **all 328 saved frame indices**, not just the audit's representative eight.

Do not embed 328 × 184k × 3 coordinates plus all raw observations into one huge HTML document. Generate bounded **per-frame binary or compressed source data** and load on demand from a local HTTP server with a small LRU cache, or provide an alternative well-documented locally streamed route.

Provide explicit controls:
- display point budget: "ALL", 200k, 50k, 10k, etc., with numeric labels;
- stable deterministic point-ID subsampling for reduced modes (same IDs across frames);
- hidden/filtered point count exactly shown;
- confidence/missing-observation coloring, independently from point sampling;
- outlier visibility toggle and independent camera-fit modes.

Use all points for computations, not only the selected display sample. Do not truncate discovered tracks at 64.
The original 512/4096/6000 caps cannot silently remain in the production viewer.

Avoid recomputing old trajectories or re-running the IEKF just to export/debug the viewer.
Do not mutate original stored states, covariances, correspondence owners or coverage flags.

## UI stability and outliers

Do not set the view extent to the extrema of long-unobserved predicted points by default.
Compute object-focused camera once from foreground samples at stable observed frames, with sensible margin and explicit ROI, then keep its target and zoom constant during playback.

Render directly observed SOLVED points separately from predictions.
Put predicted points spatially outside the measured ROI in another independently toggleable layer (outlier is a **viewer diagnostic**, NOT a filter rejection or new physical constraint).
Counts and original data remain unchanged regardless of the layer toggle.

Provide a dedicated "fit all" command to inspect those predictions; switching back must restore real-object framing.
The viewer should make the tens-of-meter point excursions visible as a problem rather than either hiding them permanently or shrinking the actual object to a dot.

## Audited numerical facts that must appear as smoke-test references

Attached audit (reuslts(4).zip, same bytes as reuslts(3).zip):
- 328 frames × 3 cameras; 54,970,499 valid foreground observations.
- original ownership 36,535,367 explained / 18,435,132 unmatched.
- corrected geometric kNN 45,855,798 explained / 9,114,701 unexplained.
- geometry+RGB 44,810,732 explained / 10,159,767 unexplained.
- 1,179,399 appearance-incompatible observations still have immutable frozen filter owners (not new seeds).
- sample at frame 327, camera 0: 4096 shown SOLVED, 1728 measured-update, 2368 prediction-only. Among sampled measured-updated positions 95.1% inside observed-surface bounds; among prediction-only positions 17.6% inside.
- sample at frame 327: predicted SOLVED coordinate range spans about X[-32.75,12.37], Y[-32.39,26.77], Z[-12.14,15.87] meters, while the foreground measured ROI is approximately X[-1.07,-0.54],Y[0.13,0.62],Z[-0.045,0.46] meters.
- The bounded insertion reports one point with 110 frames of actual observation updates, max principal position std 0.850152m, 425,893 additional appearance-compatible coverage samples, but only 172 additional assimilated observations. Never represent this as confirmation of 425,893 new physical points.

All numbers are from the supplied audit and Codex's report; the new viewer should calculate corresponding runtime metrics from each selected actual run, not hardcode them.

## Deliverables

1. Port/rewrite `pointwise_rgbd/visualization.py::trajectory_viewer`, and update `tools/audit_surface_correspondence.py` to use the shared viewer interface. Keep the existing PNG/CSV/JSON numerics.
2. Export both the full-sequence viewer and the 8-snapshot audit viewer with consistent visual identity and camera conventions.
3. Provide deterministic browser QA with a headless browser (if available), including: load from local server; no console error; frame first/last; camera switch; policy switch; measured focus; fit all; outlier toggle; loaded point counts; actual measurement vs predicted classification; old and newly appended point IDs.
4. Ensure no hardcoded 512-point or 64-discovery truncation remains. If an explicit display budget is set, display it and the hidden point count.
5. Produce a before/after screenshot **from the exact same saved state and camera pose**, and show a last-frame screenshot both focused on real measured geometry and with outliers enabled.
6. Verify that generating the debug files makes **zero IEKF/UKF updates** and does not change stored states/covariances or the source dataset. Keep the same numerical coverage results.
7. Report sources changed and benchmark browser memory/load times.

## Separate scientific diagnostic (do not modify filtering without approval)

The 6D constant-velocity predictor frequently drifts during long measurement gaps. The high-\u03c3 predictions may receive extensive geometric coverage under covariance-expanded acceptance. Plot coverage contributors split by whether the SOLVED witness had a **real update that frame** and by the last real observation age and covariance eigenvalues. Report whether broad prediction-only coverage is dominating. Do NOT silently fix this by tightening an uncalibrated threshold, truncating old points, inventing rigid groups, or constraining their trajectories.

**Acceptance:** the full object must be clearly visible in normal view; no unexplained fixed cap or hidden predicted points; the interface must match the reference's dark layout, persistent Three.js point-cloud animation, checkbox layers, orbit/pan/zoom and temporal slider while retaining the exact pointwise RGB-D semantics.
